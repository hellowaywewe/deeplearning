import os
from flask import Flask, request
import json

import mindspore.context as context
from src.yolo import YOLOV3DarkNet53
from mindspore.train.serialization import load_checkpoint, load_param_into_net
from src.config import ConfigYOLOV3DarkNet53
from mindspore import Tensor
import mindspore as ms
from src.detection import DetectionEngine


app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'hello world'


@app.route('/predict', methods=['POST'])
def predict(instance):

    context.set_context(mode=context.GRAPH_MODE, device_target='GPU', save_graphs=False)
    network = YOLOV3DarkNet53(is_training=False)
    pretrained_ckpt = '/etc/yolov3/yolov3.ckpt'
    if not os.path.exists(pretrained_ckpt):
        err_msg = "The yolov3.ckpt file does not exist!"
        return {"status": 1, "err_msg": err_msg}
    param_dict = load_checkpoint(pretrained_ckpt)
    param_dict_new = {}
    for key, values in param_dict.items():
        if key.startswith('moments.'):
            continue
        elif key.startswith('yolo_network.'):
            param_dict_new[key[13:]] = values
        else:
            param_dict_new[key] = values
    load_param_into_net(network, param_dict_new)

    config = ConfigYOLOV3DarkNet53()

    # init detection engine
    args = dict()
    args.ignore_threshold = 0.01
    args.nms_thresh = 0.5
    detection = DetectionEngine(args)

    input_shape = Tensor(tuple(config.test_img_shape), ms.float32)
    print('Start inference....')
    network.set_train(False)
    image = json.loads(instance['data'])
    prediction = network(Tensor(image.reshape(1, 3, 416, 416), ms.float32), input_shape)
    output_big, output_me, output_small = prediction
    output_big = output_big.asnumpy()
    output_me = output_me.asnumpy()
    output_small = output_small.asnumpy()

    per_batch_size = 1
    image_shape = json.loads(instance['shape'])
    detection.detect([output_small, output_me, output_big], per_batch_size,
                     image_shape, config)
    detection.do_nms_for_results()
    return detection
    return {
        "status": 0,
        "detection": detection
    }


if __name__ == '__main__':
    app.run(port=80, debug=True)
